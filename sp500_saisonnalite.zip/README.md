# S&P 500 Saisonnière 📈

Cette application Streamlit permet d’analyser les rendements saisonniers des titres du S&P 500 entre deux dates spécifiques sur plusieurs années.

## Utilisation

1. Entrez le nombre d’années, l’année de fin, et les dates de début/fin.
2. L’application télécharge les données et calcule :
   - Rendement moyen
   - Médiane
   - Écart-type
   - Pourcentage d’années positives

3. Un fichier Excel contenant les résultats est téléchargeable.
